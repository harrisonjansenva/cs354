#include <stdio.h>

void greet(const char *name) {
  printf("Hello, %s!\n", name);
}
