#include <stdio.h>
#include "greet.h"

int main() {
  greet("Max");
}
