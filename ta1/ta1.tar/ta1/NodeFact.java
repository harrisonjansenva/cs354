public abstract class NodeFact extends Node {}
